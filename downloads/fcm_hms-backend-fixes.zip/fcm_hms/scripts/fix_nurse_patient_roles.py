"""One-time cleanup for users that /auth/send-otp wrongly created as PATIENT.

Old behaviour: requesting an OTP created `User(role="PATIENT")` + an empty
`PatientProfile` immediately. Nurses/caretakers/doctors/staff who typed their
phone on the login screen before signing up therefore became PATIENTs.

What this script does:
  1. Any PATIENT user that already has a Nurse/Doctor/Staff profile  -> role fixed
     and the junk auto-created PatientProfile removed.
  2. Any PATIENT user with no name, no real profile data and no activity
     -> reported as junk (deleted only with --delete-junk).

Usage:
    python -m scripts.fix_nurse_patient_roles              # dry run (safe)
    python -m scripts.fix_nurse_patient_roles --apply      # fix roles
    python -m scripts.fix_nurse_patient_roles --apply --delete-junk
"""

import argparse
import sys

from core.database import init_db
from models import (
    DoctorProfile,
    NurseDuty,
    NurseProfile,
    PatientProfile,
    StaffProfile,
    User,
)


def profile_has_data(profile) -> bool:
    if not profile:
        return False
    return bool(
        profile.age
        or profile.address
        or profile.medical_history
        or profile.documents
        or profile.assigned_doctor
        or profile.assigned_caretaker
        or profile.service_start
        or profile.created_by == "ADMIN"
    )


def real_role_of(user):
    if NurseProfile.objects(user=user).first():
        return "NURSE"
    if DoctorProfile.objects(user=user).first():
        return "DOCTOR"
    if StaffProfile.objects(user=user).first():
        return "STAFF"
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true", help="write changes")
    parser.add_argument(
        "--delete-junk",
        action="store_true",
        help="also delete empty PATIENT accounts created by stray OTP requests",
    )
    args = parser.parse_args()

    init_db()

    fixed, junk = [], []

    for user in User.objects(role="PATIENT"):
        profile = PatientProfile.objects(user=user).first()
        role = real_role_of(user)

        if role:
            fixed.append((user, role, profile))
            continue

        if not (user.name or "").strip() and not profile_has_data(profile):
            if profile and NurseDuty.objects(patient=profile).first():
                continue
            junk.append((user, profile))

    print(f"Role mismatches (PATIENT but actually something else): {len(fixed)}")
    for user, role, _ in fixed:
        print(f"  {user.phone:<15} PATIENT -> {role}")

    print(f"\nEmpty PATIENT shells from stray OTP requests: {len(junk)}")
    for user, _ in junk:
        print(f"  {user.phone}")

    if not args.apply:
        print("\nDry run. Re-run with --apply to write the changes.")
        return 0

    for user, role, profile in fixed:
        user.role = role
        user.save()
        if profile and not profile_has_data(profile):
            profile.delete()
    print(f"\n✅ Fixed {len(fixed)} roles")

    if args.delete_junk:
        for user, profile in junk:
            if profile:
                profile.delete()
            user.delete()
        print(f"🧹 Deleted {len(junk)} empty PATIENT accounts")
    else:
        print("ℹ️  Junk accounts kept (pass --delete-junk to remove them)")

    return 0


if __name__ == "__main__":
    sys.exit(main())
